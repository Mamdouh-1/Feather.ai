from django.apps import AppConfig


class SavedCopiesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'saved_copies'

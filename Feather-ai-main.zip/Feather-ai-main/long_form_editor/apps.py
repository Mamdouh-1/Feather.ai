from django.apps import AppConfig


class LongFormEditorConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'long_form_editor'

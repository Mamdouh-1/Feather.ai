from django.apps import AppConfig


class LibraryTemplateConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'library_template'
